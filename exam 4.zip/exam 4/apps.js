function showText1() {
    document.querySelector('.text75').style = 'visibility: visible;'
    document.querySelector('.img30').style = 'opacity: 0.2;'
}
function hideText1() {
    document.querySelector('.text75').style = 'visibility: hidden;'
    document.querySelector('.img30').style = 'opacity: 1;'
}


function showText2() {
    document.querySelector('.text76').style = 'visibility: visible;'
    document.querySelector('.img31').style = 'opacity: 0.2;'
}
function hideText2() {
    document.querySelector('.text76').style = 'visibility: hidden;'
    document.querySelector('.img31').style = 'opacity: 1;'
}


function showText3() {
    document.querySelector('.text77').style = 'visibility: visible;'
    document.querySelector('.img32').style = 'opacity: 0.2;'
}
function hideText3() {
    document.querySelector('.text77').style = 'visibility: hidden;'
    document.querySelector('.img32').style = 'opacity: 1;'
}